import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(form:NgForm){
    if(form.value.username==='doctor'&& form.value.password ==='doctor123'){
      alert('welcome admin');
      }
      else{
        alert('invalid credential');
      }
    }
    Signup(form:NgForm){
      this.router.navigateByUrl('DoctorSignup');
    }
}
  