import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { AdminsignupComponent } from './adminsignup/adminsignup.component';
import { DoctorComponent } from './doctor/doctor.component';
import { DoctorsignupComponent } from './doctorsignup/doctorsignup.component';
import { HomeComponent } from './home/home.component';
import { PatientComponent } from './patient/patient.component';
import { PatientsignupComponent } from './patientsignup/patientsignup.component';

const routes: Routes = [
  { path: '', component:HomeComponent},
  { path: 'Admin', component:AdminComponent},
  { path: 'Doctor', component:DoctorComponent},
  { path: 'Patient', component:PatientComponent},
  { path: 'AdminSignup', component:AdminsignupComponent},
  { path: 'PatientSignup', component:PatientsignupComponent},
  { path: 'DoctorSignup', component:DoctorsignupComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
