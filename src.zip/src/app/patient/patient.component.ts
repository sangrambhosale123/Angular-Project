import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(form:NgForm){
    if(form.value.username === 'patient' && form.value.password === 'patient123'){
      alert('welcome patient');
    }
    else{
      alert('Invalidate Credential');
    }
  }
  Signup(form:NgForm){
    this.router.navigateByUrl('PatientSignup');
  }
}
